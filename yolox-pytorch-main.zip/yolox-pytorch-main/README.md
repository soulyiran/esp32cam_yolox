这是根据

https://gitee.com/the-story-of-technology-house/esp32-python-image-recognition

https://github.com/bubbliiiing/yolox-pytorch

修改的使用esp32cam图像采集 yolox目标检测的PC端代码

运行esp32cam.py启动
